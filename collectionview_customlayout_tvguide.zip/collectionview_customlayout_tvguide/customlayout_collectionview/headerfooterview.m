//
//  headerfooterview.m
//  customlayout_collectionview
//
//  Created by Rajeeva Ranjan on 02/04/17.
//  Copyright © 2017 Rajeeva Ranjan. All rights reserved.
//

#import "headerfooterview.h"

@implementation headerfooterview

@end
