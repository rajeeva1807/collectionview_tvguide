//
//  headerfooterview.h
//  customlayout_collectionview
//
//  Created by Rajeeva Ranjan on 02/04/17.
//  Copyright © 2017 Rajeeva Ranjan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface headerfooterview : UICollectionReusableView

@end
