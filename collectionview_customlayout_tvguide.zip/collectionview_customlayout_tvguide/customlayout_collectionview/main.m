//
//  main.m
//  customlayout_collectionview
//
//  Created by Rajeeva Ranjan on 14/02/17.
//  Copyright © 2017 Rajeeva Ranjan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
