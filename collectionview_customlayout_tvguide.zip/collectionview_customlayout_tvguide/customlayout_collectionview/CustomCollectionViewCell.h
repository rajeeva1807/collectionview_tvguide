//
//  CustomCollectionViewCell.h
//  customlayout_collectionview
//
//  Created by Rajeeva Ranjan on 02/04/17.
//  Copyright © 2017 Rajeeva Ranjan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCollectionViewCell : UICollectionViewCell

@property UILabel *myLabel;
//@property BOOL isHeader;
//@property CGFloat startOffset;
//@property CGFloat endOffset;

@end
